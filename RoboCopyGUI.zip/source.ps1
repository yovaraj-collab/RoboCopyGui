<#
.SYNOPSIS
  JW COPY Master Tool - English Edition
.DESCRIPTION
  A GUI tool for robocopy operations: copy, sync, compare, and clean folders.
.NOTES
  Version:        1.1 EN
  Author:         Yovaraj / Jörn Walter (GUI extension)
  Translation:    English Edition
  Creation Date:  10-June-2026

  Copyright (c) Yovaraj / Jörn Walter. All rights reserved.
  Web: https://linkr.ee/yovaraj
#>

# No admin elevation - run as current user
$OutputEncoding = [System.Text.Encoding]::UTF8

# Load assemblies
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Log file name generator
function Get-LogFileName {
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $desktopPath = [Environment]::GetFolderPath("Desktop")
        $logDir = Join-Path $desktopPath "RCOPYLOGS"

        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
            Write-Log "Log directory created: $logDir"
        }

        return Join-Path $logDir "robocopy_$timestamp.log"
    }
    catch {
        throw
    }
}

# Refresh path combo boxes
function Update-PathComboBoxes {
    $paths = Load-Paths

    $cmbSource.Items.Clear()
    $cmbTarget.Items.Clear()

    foreach ($path in $paths) {
        $cmbSource.Items.Add($path.SourcePath)
        $cmbTarget.Items.Add($path.TargetPath)
    }
}

function Get-ConfigPath {
    try {
        $configDir = Join-Path $env:APPDATA "RobocopyGUI"
        if (-not (Test-Path $configDir)) {
            New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        }
        return Join-Path $configDir "paths.json"
    }
    catch {
        throw
    }
}

function Save-Paths {
    param(
        [string]$SourcePath,
        [string]$TargetPath
    )

    try {
        $configPath = Get-ConfigPath
        $existingPaths = @()
        if (Test-Path $configPath) {
            $existingPaths = Get-Content -Path $configPath -Encoding UTF8 | ConvertFrom-Json
        }

        $newPath = @{
            "SourcePath" = $SourcePath
            "TargetPath" = $TargetPath
            "LastSaved"  = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        }

        $existingPaths = @($existingPaths | Where-Object {
            $_.SourcePath -ne $SourcePath -or $_.TargetPath -ne $TargetPath
        })

        $existingPaths = @($newPath) + $existingPaths

        if ($existingPaths.Count -gt 10) {
            $existingPaths = $existingPaths[0..9]
        }

        $json = $existingPaths | ConvertTo-Json
        Set-Content -Path $configPath -Value $json -Encoding UTF8

        Update-PathComboBoxes
    }
    catch {
        throw
    }
}

function Load-Paths {
    try {
        $configPath = Get-ConfigPath
        if (Test-Path $configPath) {
            $paths = Get-Content -Path $configPath -Encoding UTF8 | ConvertFrom-Json
            return $paths
        }
        return @()
    }
    catch {
        return @()
    }
}

# Main form
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Robocopy GUI Tool'
$form.Size = New-Object System.Drawing.Size(1000, 730)
$form.StartPosition = 'CenterScreen'

# Output / log window
$txtOutput = New-Object System.Windows.Forms.TextBox
$txtOutput.Location = New-Object System.Drawing.Point(20, 480)
$txtOutput.Size = New-Object System.Drawing.Size(940, 150)
$txtOutput.Multiline = $true
$txtOutput.ScrollBars = "Vertical"
$txtOutput.ReadOnly = $true
$txtOutput.Font = New-Object System.Drawing.Font("Consolas", 9)
$form.Controls.Add($txtOutput)

function Write-Log {
    param($Message)
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logMessage = "[$timestamp] $Message"

        if ($txtOutput -ne $null) {
            $txtOutput.AppendText("$logMessage`r`n")
            $txtOutput.Select($txtOutput.Text.Length, 0)
            $txtOutput.ScrollToCaret()
        }

        if ($chkCreateLog.Checked) {
            $logFile = Get-LogFileName
            Add-Content -Path $logFile -Value $logMessage -Encoding UTF8
        }
    }
    catch {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $fallbackMessage = "[$timestamp] $($Message -replace '[^\x20-\x7E]', '?')"

        if ($txtOutput -ne $null) {
            $txtOutput.AppendText("$fallbackMessage`r`n")
            $txtOutput.Select($txtOutput.Text.Length, 0)
            $txtOutput.ScrollToCaret()
        }
    }
}

function Parse-RobocopyOutput {
    param (
        [string[]]$Output
    )

    $stats = @{
        Files       = 0
        Directories = 0
    }

    Write-Log "Parsing Robocopy output..."

    foreach ($line in $Output) {
        Write-Log "Analyzing line: $line"

        if ($line -match '^\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$') {
            Write-Log "Found statistics line: $line"
            $stats.Files = [int]$Matches[1]
            Write-Log "Extracted total files: $($stats.Files)"
            break
        }

        if ($line -match 'Files\s*:\s*(\d+)' -or
            $line -match 'Copied\s*:\s*(\d+)') {
            $stats.Files = [int]$Matches[1]
            Write-Log "Found files count: $($stats.Files)"
        }
    }

    Write-Log "Parsing complete. Total files: $($stats.Files)"
    return $stats
}

[System.Windows.Forms.Control]::DefaultMarginChanged
$txtOutput.Refresh()

# --- GUI Elements ---

$lblSource = New-Object System.Windows.Forms.Label
$lblSource.Location = New-Object System.Drawing.Point(20, 20)
$lblSource.Size = New-Object System.Drawing.Size(100, 20)
$lblSource.Text = 'Source folder:'
$form.Controls.Add($lblSource)

$lblTarget = New-Object System.Windows.Forms.Label
$lblTarget.Location = New-Object System.Drawing.Point(20, 80)
$lblTarget.Size = New-Object System.Drawing.Size(100, 20)
$lblTarget.Text = 'Target folder:'
$form.Controls.Add($lblTarget)

# Path combo boxes
$cmbSource = New-Object System.Windows.Forms.ComboBox
$cmbSource.Location = New-Object System.Drawing.Point(20, 40)
$cmbSource.Size = New-Object System.Drawing.Size(800, 20)
$cmbSource.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDown
$form.Controls.Add($cmbSource)

$txtSource = New-Object System.Windows.Forms.TextBox
$txtSource.Location = New-Object System.Drawing.Point(20, 60)
$txtSource.Size = New-Object System.Drawing.Size(800, 20)
$form.Controls.Add($txtSource)

$cmbTarget = New-Object System.Windows.Forms.ComboBox
$cmbTarget.Location = New-Object System.Drawing.Point(20, 100)
$cmbTarget.Size = New-Object System.Drawing.Size(800, 20)
$cmbTarget.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDown
$form.Controls.Add($cmbTarget)

$txtTarget = New-Object System.Windows.Forms.TextBox
$txtTarget.Location = New-Object System.Drawing.Point(20, 120)
$txtTarget.Size = New-Object System.Drawing.Size(800, 20)
$form.Controls.Add($txtTarget)

# Browse buttons
$btnSourceBrowse = New-Object System.Windows.Forms.Button
$btnSourceBrowse.Location = New-Object System.Drawing.Point(830, 40)
$btnSourceBrowse.Size = New-Object System.Drawing.Size(100, 20)
$btnSourceBrowse.Text = 'Browse'
$form.Controls.Add($btnSourceBrowse)

$btnTargetBrowse = New-Object System.Windows.Forms.Button
$btnTargetBrowse.Location = New-Object System.Drawing.Point(830, 100)
$btnTargetBrowse.Size = New-Object System.Drawing.Size(100, 20)
$btnTargetBrowse.Text = 'Browse'
$form.Controls.Add($btnTargetBrowse)

# Days input
$lblDays = New-Object System.Windows.Forms.Label
$lblDays.Location = New-Object System.Drawing.Point(20, 200)
$lblDays.Size = New-Object System.Drawing.Size(130, 20)
$lblDays.Text = 'Last x days:'
$form.Controls.Add($lblDays)

$numDays = New-Object System.Windows.Forms.NumericUpDown
$numDays.Location = New-Object System.Drawing.Point(150, 200)
$numDays.Size = New-Object System.Drawing.Size(60, 20)
$numDays.Minimum = 1
$numDays.Maximum = 365
$numDays.Value = 7
$form.Controls.Add($numDays)

# Main action buttons
$btnCreateStructure = New-Object System.Windows.Forms.Button
$btnCreateStructure.Location = New-Object System.Drawing.Point(20, 160)
$btnCreateStructure.Size = New-Object System.Drawing.Size(190, 30)
$btnCreateStructure.Text = 'Create Folder Structure'
$form.Controls.Add($btnCreateStructure)

$btnCopyData = New-Object System.Windows.Forms.Button
$btnCopyData.Location = New-Object System.Drawing.Point(230, 160)
$btnCopyData.Size = New-Object System.Drawing.Size(190, 30)
$btnCopyData.Text = 'Copy Data'
$form.Controls.Add($btnCopyData)

$btnSync = New-Object System.Windows.Forms.Button
$btnSync.Location = New-Object System.Drawing.Point(230, 200)
$btnSync.Size = New-Object System.Drawing.Size(190, 30)
$btnSync.Text = 'Synchronize'
$form.Controls.Add($btnSync)

$btnDelete = New-Object System.Windows.Forms.Button
$btnDelete.Location = New-Object System.Drawing.Point(20, 240)
$btnDelete.Size = New-Object System.Drawing.Size(190, 30)
$btnDelete.Text = 'Clean Target'
$form.Controls.Add($btnDelete)

$btnCompare = New-Object System.Windows.Forms.Button
$btnCompare.Location = New-Object System.Drawing.Point(230, 240)
$btnCompare.Size = New-Object System.Drawing.Size(190, 30)
$btnCompare.Text = 'Compare Folders'
$form.Controls.Add($btnCompare)

# Date-based deletion controls
$lblDeleteDate = New-Object System.Windows.Forms.Label
$lblDeleteDate.Location = New-Object System.Drawing.Point(440, 160)
$lblDeleteDate.Size = New-Object System.Drawing.Size(150, 20)
$lblDeleteDate.Text = 'Delete by date in target:'
$form.Controls.Add($lblDeleteDate)

$dtpDeleteDate = New-Object System.Windows.Forms.DateTimePicker
$dtpDeleteDate.Location = New-Object System.Drawing.Point(440, 180)
$dtpDeleteDate.Size = New-Object System.Drawing.Size(150, 20)
$dtpDeleteDate.Format = [System.Windows.Forms.DateTimePickerFormat]::Short
$form.Controls.Add($dtpDeleteDate)

# Date type radio buttons
$gbDateType = New-Object System.Windows.Forms.GroupBox
$gbDateType.Location = New-Object System.Drawing.Point(600, 160)
$gbDateType.Size = New-Object System.Drawing.Size(200, 50)
$gbDateType.Text = "Date Type"

$rbCreationDate = New-Object System.Windows.Forms.RadioButton
$rbCreationDate.Location = New-Object System.Drawing.Point(10, 20)
$rbCreationDate.Size = New-Object System.Drawing.Size(90, 20)
$rbCreationDate.Text = "Created"
$rbCreationDate.Checked = $true
$gbDateType.Controls.Add($rbCreationDate)

$rbModifiedDate = New-Object System.Windows.Forms.RadioButton
$rbModifiedDate.Location = New-Object System.Drawing.Point(100, 20)
$rbModifiedDate.Size = New-Object System.Drawing.Size(90, 20)
$rbModifiedDate.Text = "Modified"
$gbDateType.Controls.Add($rbModifiedDate)

$form.Controls.Add($gbDateType)

$btnDeleteByDate = New-Object System.Windows.Forms.Button
$btnDeleteByDate.Location = New-Object System.Drawing.Point(440, 215)
$btnDeleteByDate.Size = New-Object System.Drawing.Size(190, 30)
$btnDeleteByDate.Text = 'Delete by Date'
$form.Controls.Add($btnDeleteByDate)

# Pattern-based deletion controls
$lblNamePattern = New-Object System.Windows.Forms.Label
$lblNamePattern.Location = New-Object System.Drawing.Point(440, 250)
$lblNamePattern.Size = New-Object System.Drawing.Size(150, 20)
$lblNamePattern.Text = 'Pattern:'
$form.Controls.Add($lblNamePattern)

$txtNamePattern = New-Object System.Windows.Forms.TextBox
$txtNamePattern.Location = New-Object System.Drawing.Point(440, 270)
$txtNamePattern.Size = New-Object System.Drawing.Size(180, 20)
$form.Controls.Add($txtNamePattern)

$btnDeleteByPattern = New-Object System.Windows.Forms.Button
$btnDeleteByPattern.Location = New-Object System.Drawing.Point(440, 300)
$btnDeleteByPattern.Size = New-Object System.Drawing.Size(190, 30)
$btnDeleteByPattern.Text = 'Delete by Pattern in Target'
$form.Controls.Add($btnDeleteByPattern)

# Log option
$chkCreateLog = New-Object System.Windows.Forms.CheckBox
$chkCreateLog.Location = New-Object System.Drawing.Point(770, 410)
$chkCreateLog.Size = New-Object System.Drawing.Size(300, 20)
$chkCreateLog.Text = "Create Robocopy log file"
$chkCreateLog.Checked = $true
$form.Controls.Add($chkCreateLog)

# Copyright label
$lblCopyright = New-Object System.Windows.Forms.Label
$lblCopyright.Location = New-Object System.Drawing.Point(690, 640)
$lblCopyright.Size = New-Object System.Drawing.Size(400, 20)
$lblCopyright.Text = '� 2026 Yovaraj https://linktr.ee/yovaraj'
$lblCopyright.ForeColor = [System.Drawing.Color]::Gray
$form.Controls.Add($lblCopyright)

# Status bar
$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "Ready"
$statusStrip.Items.Add($statusLabel)
$form.Controls.Add($statusStrip)

# ComboBox event handlers
$cmbSource.Add_SelectedIndexChanged({
    if ($cmbSource.SelectedIndex -ge 0) {
        $paths = Load-Paths
        $selectedPath = $paths[$cmbSource.SelectedIndex]
        $txtSource.Text = $selectedPath.SourcePath
        $txtTarget.Text = $selectedPath.TargetPath
        $cmbTarget.SelectedIndex = $cmbSource.SelectedIndex
    }
})

$cmbTarget.Add_SelectedIndexChanged({
    if ($cmbTarget.SelectedIndex -ge 0) {
        $paths = Load-Paths
        $selectedPath = $paths[$cmbTarget.SelectedIndex]
        $txtTarget.Text = $selectedPath.TargetPath
    }
})

# Path validation (local and UNC)
function Test-ValidPath {
    param (
        [string]$Path
    )

    try {
        if ([string]::IsNullOrWhiteSpace($Path)) {
            Write-Log "Empty path supplied"
            return $false
        }

        if ($Path.StartsWith("\\")) {
            if ($Path -match '^\\\\[^\\]+\\[^\\]+(?:\\.*)?$') {
                if (Test-Path -Path $Path -ErrorAction SilentlyContinue) {
                    return $true
                }
                Write-Log "UNC path not reachable: $Path"
                return $false
            }
            Write-Log "Invalid UNC path format: $Path"
            return $false
        }

        if (Test-Path -Path $Path -ErrorAction SilentlyContinue) {
            return $true
        }

        Write-Log "Path not found: $Path"
        return $false
    }
    catch {
        Write-Log "Error during path validation: $_"
        return $false
    }
}

# Normalize paths
function Get-NormalizedPath {
    param (
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ""
    }

    if ($Path.Length -gt 3 -and $Path.EndsWith('\')) {
        $Path = $Path.TrimEnd('\')
    }

    if ($Path.StartsWith('\\')) {
        $Path = '\\' + ($Path.Substring(2) -replace '\\+', '\')
    }
    else {
        $Path = $Path -replace '\\+', '\'
    }

    return $Path
}

# Browse button event handlers
$btnSourceBrowse.Add_Click({
    $result = Show-FolderDialog -Title "Select source folder" -InitialDirectory $txtSource.Text
    if ($result.Success) {
        $txtSource.Text = $result.SelectedPath
        $cmbSource.Text = $result.SelectedPath
    }
})

$btnTargetBrowse.Add_Click({
    $result = Show-FolderDialog -Title "Select target folder" -InitialDirectory $txtTarget.Text
    if ($result.Success) {
        $txtTarget.Text = $result.SelectedPath
        $cmbTarget.Text = $result.SelectedPath
    }
})

# Folder selection dialog
function Show-FolderDialog {
    param (
        [string]$Title,
        [string]$InitialDirectory
    )

    $customPathForm = New-Object System.Windows.Forms.Form
    $customPathForm.Text = $Title
    $customPathForm.Size = New-Object System.Drawing.Size(600, 200)
    $customPathForm.StartPosition = 'CenterScreen'
    $customPathForm.FormBorderStyle = 'FixedDialog'
    $customPathForm.MaximizeBox = $false
    $customPathForm.MinimizeBox = $false

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Location = New-Object System.Drawing.Point(10, 10)
    $lblInfo.Size = New-Object System.Drawing.Size(560, 40)
    $lblInfo.Text = "Please enter a path or select a local folder.`nUNC paths are allowed (e.g. \\SERVER\Share\Folder)"
    $customPathForm.Controls.Add($lblInfo)

    $txtPath = New-Object System.Windows.Forms.TextBox
    $txtPath.Location = New-Object System.Drawing.Point(10, 60)
    $txtPath.Size = New-Object System.Drawing.Size(560, 20)
    if (-not [string]::IsNullOrWhiteSpace($InitialDirectory)) {
        $txtPath.Text = $InitialDirectory
    }
    $customPathForm.Controls.Add($txtPath)

    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Location = New-Object System.Drawing.Point(10, 90)
    $btnBrowse.Size = New-Object System.Drawing.Size(180, 23)
    $btnBrowse.Text = "Browse local folder..."
    $btnBrowse.Add_Click({
        $folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
        $folderBrowser.Description = $Title

        if (-not [string]::IsNullOrWhiteSpace($txtPath.Text) -and (Test-Path -Path $txtPath.Text -ErrorAction SilentlyContinue)) {
            $folderBrowser.SelectedPath = $txtPath.Text
        }

        if ($folderBrowser.ShowDialog() -eq 'OK') {
            $txtPath.Text = $folderBrowser.SelectedPath
        }
    })
    $customPathForm.Controls.Add($btnBrowse)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Location = New-Object System.Drawing.Point(400, 120)
    $btnOK.Size = New-Object System.Drawing.Size(75, 23)
    $btnOK.Text = "OK"
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $customPathForm.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Location = New-Object System.Drawing.Point(490, 120)
    $btnCancel.Size = New-Object System.Drawing.Size(75, 23)
    $btnCancel.Text = "Cancel"
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $customPathForm.Controls.Add($btnCancel)

    $customPathForm.AcceptButton = $btnOK
    $customPathForm.CancelButton = $btnCancel

    $result = @{
        Success      = $false
        SelectedPath = ""
    }

    $dialogResult = $customPathForm.ShowDialog()
    if ($dialogResult -eq [System.Windows.Forms.DialogResult]::OK) {
        if (-not [string]::IsNullOrWhiteSpace($txtPath.Text)) {
            $selectedPath = Get-NormalizedPath -Path $txtPath.Text
            if (Test-ValidPath -Path $selectedPath) {
                $result.Success = $true
                $result.SelectedPath = $selectedPath
            }
            else {
                [System.Windows.Forms.MessageBox]::Show(
                    "The entered path is invalid or not reachable.`nPlease check the path and try again.",
                    "Invalid Path",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )
            }
        }
        else {
            [System.Windows.Forms.MessageBox]::Show(
                "Please enter a path or select a local folder.",
                "Missing Path",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
        }
    }

    $customPathForm.Dispose()
    return $result
}

# Create Folder Structure button
$btnCreateStructure.Add_Click({
    if ([string]::IsNullOrEmpty($txtSource.Text) -or [string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select both source and target folders.", "Error")
        return
    }

    try {
        Write-Log "Creating folder structure..."
        Write-Log "Source: $($txtSource.Text)"
        Write-Log "Target: $($txtTarget.Text)"

        $roboParams = @($txtSource.Text, $txtTarget.Text, "/E", "/XF", "*", "/COPYALL")

        if ($chkCreateLog.Checked) {
            $logFile = Get-LogFileName
            $roboParams += "/LOG:$logFile"
            Write-Log "Log file will be created at: $logFile"
        }

        $output = robocopy @roboParams

        foreach ($line in $output) {
            Write-Log $line
        }

        Save-Paths -SourcePath $txtSource.Text -TargetPath $txtTarget.Text

        Write-Log "Folder structure created"
        [System.Windows.Forms.MessageBox]::Show("Folder structure created successfully!", "Success")
    }
    catch {
        Write-Log "ERROR: $_"
        [System.Windows.Forms.MessageBox]::Show("Error creating folder structure: $_", "Error")
    }
})

# Progress bar and label
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(20, 440)
$progressBar.Size = New-Object System.Drawing.Size(940, 20)
$progressBar.Style = 'Continuous'
$form.Controls.Add($progressBar)

$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.Location = New-Object System.Drawing.Point(20, 420)
$lblProgress.Size = New-Object System.Drawing.Size(940, 20)
$lblProgress.Text = "Ready"
$form.Controls.Add($lblProgress)

function Update-Progress {
    param (
        [string]$Message,
        [int]$PercentComplete
    )

    $progressBar.Value = $PercentComplete
    $lblProgress.Text = "$Message - $PercentComplete%"
    [System.Windows.Forms.Application]::DoEvents()
}

function Reset-Progress {
    $progressBar.Value = 0
    $lblProgress.Text = "Ready"
    [System.Windows.Forms.Application]::DoEvents()
}

# Copy Data button
$btnCopyData.Add_Click({
    if ([string]::IsNullOrEmpty($txtSource.Text) -or [string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select both source and target folders.", "Error")
        return
    }

    try {
        Reset-Progress
        Write-Log "Starting copy operation..."
        Write-Log "Source: $($txtSource.Text)"
        Write-Log "Target: $($txtTarget.Text)"

        $sourcePath = $txtSource.Text.TrimEnd('\')
        $targetPath = $txtTarget.Text.TrimEnd('\')

        $robocopyCommand = "robocopy `"$sourcePath`" `"$targetPath`" /E /COPY:DAT /R:1 /W:1 /DCOPY:DAT /MT:8"

        if ($chkCreateLog.Checked) {
            $logFile = Get-LogFileName
            $robocopyCommand += " /LOG+:`"$logFile`""
            Write-Log "Log file will be created at: $logFile"
        }

        Write-Log "Executing: $robocopyCommand"

        $job = Start-Job -ScriptBlock {
            param($cmd)
            Invoke-Expression $cmd
        } -ArgumentList $robocopyCommand

        while ($job.State -eq 'Running') {
            $progress = Get-Random -Minimum 10 -Maximum 90
            Update-Progress -Message "Copying files" -PercentComplete $progress
            Start-Sleep -Milliseconds 500
        }

        $output = Receive-Job -Job $job -Wait
        Remove-Job -Job $job -Force

        foreach ($line in $output) {
            Write-Log $line
        }

        if ($LASTEXITCODE -lt 8) {
            Update-Progress -Message "Copy completed" -PercentComplete 100
            [System.Windows.Forms.MessageBox]::Show("Files copied successfully!", "Success")
            Save-Paths -SourcePath $txtSource.Text -TargetPath $txtTarget.Text
        }
        else {
            throw "Robocopy exited with error code $LASTEXITCODE"
        }
    }
    catch {
        Write-Log "ERROR: $_"
        [System.Windows.Forms.MessageBox]::Show("Error copying data: $_", "Error")
    }
    finally {
        Reset-Progress
    }
})

# Synchronize button
$btnSync.Add_Click({
    if ([string]::IsNullOrEmpty($txtSource.Text) -or [string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select both source and target folders.", "Error")
        return
    }

    try {
        Reset-Progress
        $daysBack = $numDays.Value
        $maxAge = (Get-Date).AddDays(-$daysBack)
        $maxAgeParam = "/MAXAGE:" + $maxAge.ToString("yyyyMMdd")

        Write-Log "Starting synchronization..."
        Write-Log "Source: $($txtSource.Text)"
        Write-Log "Target: $($txtTarget.Text)"
        Write-Log "Period: Last $daysBack days"

        $sourcePath = $txtSource.Text.TrimEnd('\')
        $targetPath = $txtTarget.Text.TrimEnd('\')

        $robocopyCommand = "robocopy `"$sourcePath`" `"$targetPath`" /MIR /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /MT:8 $maxAgeParam"

        if ($chkCreateLog.Checked) {
            $logFile = Get-LogFileName
            $robocopyCommand += " /LOG+:`"$logFile`""
            Write-Log "Log file will be created at: $logFile"
        }

        Write-Log "Executing: $robocopyCommand"

        $job = Start-Job -ScriptBlock {
            param($cmd)
            Invoke-Expression $cmd
        } -ArgumentList $robocopyCommand

        while ($job.State -eq 'Running') {
            $progress = Get-Random -Minimum 10 -Maximum 90
            Update-Progress -Message "Synchronizing files" -PercentComplete $progress
            Start-Sleep -Milliseconds 500
        }

        $output = Receive-Job -Job $job -Wait
        Remove-Job -Job $job -Force

        foreach ($line in $output) {
            Write-Log $line
        }

        if ($LASTEXITCODE -lt 8) {
            Update-Progress -Message "Synchronization complete" -PercentComplete 100
            [System.Windows.Forms.MessageBox]::Show("Synchronization completed successfully!", "Success")
            Save-Paths -SourcePath $txtSource.Text -TargetPath $txtTarget.Text
        }
        else {
            throw "Robocopy exited with error code $LASTEXITCODE"
        }
    }
    catch {
        Write-Log "ERROR: $_"
        [System.Windows.Forms.MessageBox]::Show("Error during synchronization: $_", "Error")
    }
    finally {
        Reset-Progress
    }
})

# Compare Folders button
$btnCompare.Add_Click({
    if ([string]::IsNullOrEmpty($txtSource.Text) -or [string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select both source and target folders.", "Error")
        return
    }

    try {
        Reset-Progress
        Write-Log "Starting comparison..."
        Write-Log "Source: $($txtSource.Text)"
        Write-Log "Target: $($txtTarget.Text)"

        $sourcePath = $txtSource.Text.TrimEnd('\')
        $targetPath = $txtTarget.Text.TrimEnd('\')

        $robocopyCommand = "robocopy `"$sourcePath`" `"$targetPath`" /E /L"

        if ($chkCreateLog.Checked) {
            $logFile = Get-LogFileName
            $robocopyCommand += " /LOG+:`"$logFile`""
            Write-Log "Log file will be created at: $logFile"
        }

        Write-Log "Executing: $robocopyCommand"

        $job = Start-Job -ScriptBlock {
            param($cmd)
            Invoke-Expression $cmd
        } -ArgumentList $robocopyCommand

        while ($job.State -eq 'Running') {
            $progress = Get-Random -Minimum 10 -Maximum 90
            Update-Progress -Message "Comparing files" -PercentComplete $progress
            Start-Sleep -Milliseconds 500
        }

        $output = Receive-Job -Job $job -Wait
        Remove-Job -Job $job -Force

        foreach ($line in $output) {
            Write-Log $line
        }

        Update-Progress -Message "Comparison complete" -PercentComplete 100
        Write-Log "Comparison complete"
    }
    catch {
        Write-Log "ERROR: $_"
        [System.Windows.Forms.MessageBox]::Show("Error during comparison: $_", "Error")
    }
    finally {
        Reset-Progress
    }
})

# Delete by Date button
$btnDeleteByDate.Add_Click({
    if ([string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select a target folder.", "Error")
        return
    }

    $selectedDate = $dtpDeleteDate.Value.Date
    $dateType = if ($rbCreationDate.Checked) { "Creation date" } else { "Modified date" }

    $result = [System.Windows.Forms.MessageBox]::Show(
        "All files in the target directory with date $($selectedDate.ToString('MM/dd/yyyy')) ($dateType) will be deleted. Continue?",
        "Warning",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning)

    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Write-Log "Starting deletion of files with date $($selectedDate.ToString('MM/dd/yyyy'))..."
            Write-Log "Target folder: $($txtTarget.Text)"
            Write-Log "Date: $($selectedDate.ToString('MM/dd/yyyy'))"
            Write-Log "Type: $dateType"

            $files = Get-ChildItem -Path $txtTarget.Text -Recurse -File
            $count = 0

            foreach ($file in $files) {
                $dateToCheck = if ($rbCreationDate.Checked) {
                    $file.CreationTime.Date
                }
                else {
                    $file.LastWriteTime.Date
                }

                if ($dateToCheck -eq $selectedDate) {
                    Remove-Item $file.FullName -Force
                    $count++
                    Write-Log "Deleted: $($file.FullName) ($($dateToCheck.ToString('MM/dd/yyyy')))"
                }
            }

            Write-Log "Deletion complete. $count file(s) deleted."
            [System.Windows.Forms.MessageBox]::Show("$count file(s) deleted successfully!", "Success")
        }
        catch {
            Write-Log "ERROR: $_"
            [System.Windows.Forms.MessageBox]::Show("Error deleting files: $_", "Error")
        }
    }
})

# Clean Target button
$btnDelete.Add_Click({
    if ([string]::IsNullOrEmpty($txtSource.Text) -or [string]::IsNullOrEmpty($txtTarget.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select both source and target folders.", "Error")
        return
    }

    $result = [System.Windows.Forms.MessageBox]::Show(
        "This will delete files and folders in the target directory that do not exist in the source. Continue?",
        "Warning",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning)

    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Write-Log "Starting target cleanup..."
            Write-Log "Source: $($txtSource.Text)"
            Write-Log "Target: $($txtTarget.Text)"

            $roboParams = @($txtSource.Text, $txtTarget.Text, "/E", "/PURGE", "/XF", "*")

            if ($chkCreateLog.Checked) {
                $logFile = Get-LogFileName
                $roboParams += "/LOG:$logFile"
                Write-Log "Log file will be created at: $logFile"
            }

            $output = robocopy @roboParams

            foreach ($line in $output) {
                Write-Log $line
            }

            Write-Log "Cleanup complete"
            [System.Windows.Forms.MessageBox]::Show("Target cleanup completed successfully!", "Success")
        }
        catch {
            Write-Log "ERROR: $_"
            [System.Windows.Forms.MessageBox]::Show("Error during cleanup: $_", "Error")
        }
    }
})

# Delete by Pattern button
$btnDeleteByPattern.Add_Click({
    if ([string]::IsNullOrEmpty($txtTarget.Text) -or [string]::IsNullOrEmpty($txtNamePattern.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select a target folder and enter a pattern.", "Error")
        return
    }

    $pattern = $txtNamePattern.Text

    $result = [System.Windows.Forms.MessageBox]::Show(
        "This will delete all files in the target directory whose name contains '$pattern'. Continue?",
        "Warning",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning)

    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Write-Log "Starting pattern-based deletion..."
            Write-Log "Target folder: $($txtTarget.Text)"
            Write-Log "Pattern: $pattern"

            $files = Get-ChildItem -Path $txtTarget.Text -Recurse -File | Where-Object { $_.Name -like "*$pattern*" }

            $count = 0
            foreach ($file in $files) {
                Remove-Item $file.FullName -Force
                $count++
                Write-Log "Deleted: $($file.FullName)"
            }

            Write-Log "Deletion complete. $count file(s) deleted."
            [System.Windows.Forms.MessageBox]::Show("$count file(s) deleted successfully!", "Success")
        }
        catch {
            Write-Log "ERROR: $_"
            [System.Windows.Forms.MessageBox]::Show("Error deleting files: $_", "Error")
        }
    }
})

# Initialize combo boxes on startup
$form.Add_Shown({
    Write-Log "Application started"
    Update-PathComboBoxes
    $paths = Load-Paths
    if ($paths.Count -gt 0) {
        $txtSource.Text = $paths[0].SourcePath
        $txtTarget.Text = $paths[0].TargetPath
    }
})

# Context menu for the output window
$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$copyMenuItem = $contextMenu.Items.Add("Copy to clipboard")
$copyMenuItem.Add_Click({
    if ($txtOutput.Text.Length -gt 0) {
        [System.Windows.Forms.Clipboard]::SetText($txtOutput.Text)
        $statusLabel.Text = "Output copied to clipboard"
    }
})
$txtOutput.ContextMenuStrip = $contextMenu

# Launch the application
[System.Windows.Forms.Application]::Run($form)
