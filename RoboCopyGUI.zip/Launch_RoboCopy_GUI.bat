@echo off
:: ============================================================
:: RoboCopy GUI Tool - Launcher
:: Runs without administrator rights
:: ============================================================

:: Set window title
title RoboCopy GUI Tool Launcher

:: Get the directory where this .bat file lives
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%source.ps1"

:: Check that the PowerShell script exists
if not exist "%PS_SCRIPT%" (
    echo ERROR: Script not found: %PS_SCRIPT%
    echo Make sure source.ps1 is in the same folder as this launcher.
    pause
    exit /b 1
)

:: Launch PowerShell without requesting admin elevation
:: -ExecutionPolicy Bypass  : allows the script to run without changing system policy
:: -NoProfile               : faster startup, avoids profile conflicts
:: -WindowStyle Hidden      : hides the console window (GUI only)
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PS_SCRIPT%"

:: If PowerShell exited with an error, show a message
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo The script exited with error code %ERRORLEVEL%.
    pause
)
